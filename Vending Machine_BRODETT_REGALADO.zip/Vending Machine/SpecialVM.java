/**
 * Special class to be implemented later on.
 */
public class SpecialVM extends VendingMachine {
    public SpecialVM(int slotCapacity){
        super(slotCapacity);
    }
    //methods specific to this file to be implemented later...

}